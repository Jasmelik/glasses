
function onxrloaded() {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera();
  const renderer = new THREE.WebGLRenderer({ alpha: true });
  document.body.appendChild(renderer.domElement);

  XR8.addCameraPipelineModules([
    XR8.GlTextureRenderer.pipelineModule(),
    XR8.Threejs.pipelineModule(),
    XR8.FaceEffects.pipelineModule(),
    XR8.XrController.pipelineModule(),
  ]);

  XR8.run({ canvas: renderer.domElement });

  XR8.ThreeJS.loadGLTF('assets/Blue_Chic_Sunglasses_0514102543_texture.glb').then((glasses) => {
    const faceAnchor = XR8.XrController.anchorController.getFaceAnchor();
    faceAnchor.group.add(glasses.scene);
    glasses.scene.position.set(0, 0.05, 0.12);
    glasses.scene.scale.set(1.0, 1.0, 1.0);
  });
}
